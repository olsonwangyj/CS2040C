#include "LinkedList.h"

// copy the following code to coursemology without the above line of "#include "LinkedList.h""

// Returns the value at head
int List::head() {
	// TODO: Implement this method
	return 0;
}

// Checks whether the container is empty
bool List::empty() const {
	// TODO: Implement this method
	return 0;
}

// Returns the number of elements
size_t List::size() const {
	// TODO: Implement this method
	return 0;
}

// Inserts an element to the head
void List::push_head(int element) {
	// TODO: Implement this method
}

// Removes the head element
int List::pop_head() {
	// TODO: Implement this method
	return 0;
}

// Checks whether the container contains the specified element
bool List::contains(int element) const {
	// TODO: Implement this method
	return 0;
}

// Returns a std::string equivalent of the container
std::string List::to_string() const {
	// TODO: Implement this method
	return "";
}
